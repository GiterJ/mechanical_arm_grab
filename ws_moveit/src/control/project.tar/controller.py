#!/usr/bin/env python3


import sys
import rospy
import moveit_commander
from moveit_msgs.msg import DisplayTrajectory

from config import Config
from pick_place import PickPlace
from update_scene import UpdateScene
from gpd_interface import GPDInterface


class Controller(object):
    def __init__(self):
        super(Controller, self).__init__()
        config = Config()
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node(config.node_name, anonymous=True)
        robot = moveit_commander.RobotCommander()
        scene = moveit_commander.PlanningSceneInterface()
        move_group = moveit_commander.MoveGroupCommander(config.group_name)
        display_trajectory_publisher = rospy.Publisher(
            config.display_trajectory_topic,
            DisplayTrajectory,
            queue_size=20
        )
        pick_place = PickPlace(move_group)
        update_scene = UpdateScene(scene)
        
        self.robot = robot
        self.scene = scene
        self.move_group = move_group
        self.display_trajectory_publisher = display_trajectory_publisher
        self.pick_place = pick_place
        self.update_scene = update_scene
        
    def update(self):
        self.update_scene.update_scene(0)
        # self.update_scene.update_point()
        
    def pick(self):
        self.pick_place.pick(0)
        
    def place(self):
        self.pick_place.place(0)
    
        