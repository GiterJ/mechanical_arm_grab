#!/usr/bin/env python3


import rospy
from threading import Thread

from config import Config


class HardwareInterface(object):
    def __init__(self, move_group):
        super(HardwareInterface, self).__init__()
        self.config = Config()
        self.move_group = move_group
        self.thread_lock = False
        self.path = []
    
    def get_grasp_trajectory(self, grasp):
        path_thread = Thread(target=self.get_trajectory)
        path_thread.start()
        self.move_group.set_support_surface_name(self.config.table_id)
        result = self.move_group.pick(self.config.target_id, grasp)
        self.thread_lock = False
        return self.path
    
    def get_place_trajectory(self, place):
        path_thread = Thread(target=self.get_trajectory)
        path_thread.start()
        self.move_group.set_support_surface_name(self.config.table_id)
        result = self.move_group.place(self.config.target_id, place)
        self.thread_lock = False
        return self.path

    def get_trajectory(self):
        self.path = []
        rate = rospy.Rate(2.0)
        self.thread_lock = True
        while self.thread_lock:
            self.path.append(tuple(self.move_group.get_current_joint_values()))
            rate.sleep()

