#!/usr/bin/env python3


from controller import Controller


def main():
    controller = Controller()
    # input("initializing...")
    # controller.update()
    input("pick...")
    controller.pick()
    # input("place...")
    # controller.place()
    
if __name__ == "__main__":
    main()